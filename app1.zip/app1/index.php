<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
$name=$_REQUEST['name'];
$email=$_REQUEST['email'];
$mobile=$_REQUEST['mobile'];
echo $name." ".$email." ".$mobile;
	
?>
